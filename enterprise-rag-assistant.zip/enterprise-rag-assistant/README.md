# Enterprise RAG Assistant 🔎🤖

A Python-based Retrieval-Augmented Generation (RAG) assistant that retrieves
relevant enterprise knowledge before generating an answer with an LLM.

## What this project demonstrates

- Retrieval-Augmented Generation (RAG)
- Document ingestion and chunking
- Context retrieval
- LLM-based grounded responses
- Source-aware context
- Environment-based API key management
- Modular AI application architecture

## Architecture

```text
Enterprise Documents
        │
        ▼
Document Loader
        │
        ▼
Chunking
        │
        ▼
Retriever
        │
        ▼
Relevant Context
        │
        ▼
LLM
        │
        ▼
Grounded Answer
```

## Project Structure

```text
enterprise-rag-assistant/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── src/
│   ├── document_loader.py
│   ├── retriever.py
│   ├── llm.py
│   └── rag.py
├── data/
│   └── documents/
│       ├── company_policies.txt
│       └── engineering_handbook.txt
└── docs/
    └── architecture.md
```

## Run Locally

```bash
git clone https://github.com/Ashok48-ctrl/enterprise-rag-assistant.git
cd enterprise-rag-assistant
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add your OpenAI API key.

Run:

```bash
python app.py
```

Example questions:

```text
What are the remote work requirements?
How should a production incident be handled?
What is required before merging production code?
```

## RAG Design

The demonstration uses a lightweight keyword retriever so the repository can
run without a vector database. A production implementation can replace the
retriever with embeddings and a vector store such as Amazon OpenSearch,
Pinecone, pgvector, or another approved enterprise retrieval platform.

## Security

Never commit `.env`, API keys, credentials, or private enterprise documents.

The included documents are fictional sample content.

## Technologies

Python • Generative AI • LLMs • RAG • Prompt Engineering • OpenAI API •
NLP • Document Processing • Retrieval Systems
