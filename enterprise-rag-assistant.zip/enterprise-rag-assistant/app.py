import os
from dotenv import load_dotenv
from src.rag import RAGAssistant

load_dotenv()

def main():
    assistant = RAGAssistant()
    print("Enterprise RAG Assistant")
    print("Type a question, or 'exit' to quit.\n")

    while True:
        question = input("You: ").strip()
        if question.lower() in {"exit", "quit"}:
            break
        if not question:
            continue
        print("\nAssistant:", assistant.answer(question), "\n")

if __name__ == "__main__":
    main()
