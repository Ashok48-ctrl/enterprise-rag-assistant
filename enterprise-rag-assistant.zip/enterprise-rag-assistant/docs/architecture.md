# Architecture

## 1. Ingestion
Text documents are loaded from `data/documents`.

## 2. Chunking
Documents are divided into overlapping chunks to create manageable retrieval
units.

## 3. Retrieval
The demo uses a simple keyword-based retriever. This keeps the project
dependency-light while demonstrating the RAG flow.

## 4. Generation
Retrieved context is passed to an LLM with instructions to answer only from
the supplied context.

## 5. Production Evolution

For a production enterprise implementation, the retrieval layer can be upgraded
to embedding-based search with a vector database, followed by access controls,
document-level permissions, evaluation, observability, PII controls, prompt
injection defenses, and citation/traceability mechanisms.
