import os

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

class LLMClient:
    def __init__(self):
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key or OpenAI is None:
            self.client = None
        else:
            self.client = OpenAI(api_key=api_key)

    def answer(self, question, context):
        if not self.client:
            return (
                "LLM is not configured. Add OPENAI_API_KEY to your .env file. "
                "Retrieved context:\n\n" + context
            )

        response = self.client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            instructions=(
                "You are an enterprise knowledge assistant. Answer only from the "
                "provided context. If the answer is not present, say you do not "
                "have enough information. Include source names when useful."
            ),
            input=f"Question:\n{question}\n\nContext:\n{context}",
        )
        return response.output_text
