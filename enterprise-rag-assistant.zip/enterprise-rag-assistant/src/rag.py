from src.document_loader import load_documents, chunk_text
from src.retriever import KeywordRetriever
from src.llm import LLMClient

class RAGAssistant:
    def __init__(self):
        docs = load_documents()
        chunks = []
        for doc in docs:
            for index, chunk in enumerate(chunk_text(doc["text"])):
                chunks.append({
                    "source": doc["source"],
                    "chunk_id": index,
                    "text": chunk
                })
        self.retriever = KeywordRetriever(chunks)
        self.llm = LLMClient()

    def answer(self, question):
        results = self.retriever.search(question)
        if not results:
            return "I could not find relevant information in the knowledge base."

        context = "\n\n".join(
            f"[Source: {r['source']}]\n{r['text']}" for r in results
        )
        return self.llm.answer(question, context)
