import re
from collections import Counter

class KeywordRetriever:
    """Small dependency-free baseline retriever for the demo."""

    def __init__(self, chunks):
        self.chunks = chunks

    @staticmethod
    def tokens(text):
        return re.findall(r"[a-zA-Z0-9]+", text.lower())

    def search(self, query, top_k=4):
        q = Counter(self.tokens(query))
        scored = []

        for item in self.chunks:
            tokens = Counter(self.tokens(item["text"]))
            score = sum(min(q[t], tokens[t]) for t in q)
            if score:
                scored.append((score, item))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [item for _, item in scored[:top_k]]
